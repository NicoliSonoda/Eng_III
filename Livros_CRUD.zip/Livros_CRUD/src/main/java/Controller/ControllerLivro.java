package Controller;

import Dominio.*;
import Fachada.Fachada;
import Fachada.IFachada;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(urlPatterns = {"/cadastroLivro"})
public class ControllerLivro extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String titulo = request.getParameter("titulo");
        String sinopse = request.getParameter("sinopse");
        int anoPublicacao = Integer.parseInt(request.getParameter("anoPublicacao"));
        String isbn = request.getParameter("isbn");
        int numPaginas = Integer.parseInt(request.getParameter("numPaginas"));
        String codBarras = request.getParameter("codBarras");
        String edicao = request.getParameter("edicao");

        // Autores
        String autor1 = request.getParameter("autor1");
        String autor2 = request.getParameter("autor2");
        List<Autor> autores = new ArrayList<>();
        if (autor1 != null && !autor1.isEmpty()) {
            autores.add(new Autor(autor1));
        }
        if (autor2 != null && !autor2.isEmpty()) {
            autores.add(new Autor(autor2));
        }

        // Editora
        String editora = request.getParameter("editora");
        Editora editora1 = new Editora(editora);

        // Fornecedor
        String fornecedor = request.getParameter("fornecedor");
        Fornecedor fornecedor1 = new Fornecedor(fornecedor);

        // Grupo Precificação
        String grupoPrecificacao = request.getParameter("grupoPrecificacao");
        GrupoPrecificacao grupoPrecificacao1 = new GrupoPrecificacao(grupoPrecificacao);

        // Características do Livro
        float altura = Float.parseFloat(request.getParameter("altura"));
        float largura = Float.parseFloat(request.getParameter("largura"));
        float profundidade = Float.parseFloat(request.getParameter("profundidade"));
        float peso = Float.parseFloat(request.getParameter("peso"));
        CaracteristicasLivro caracteristicasLivro1 = new CaracteristicasLivro(altura, largura, profundidade, peso);

        // Categorias
        String categoriaLivro1 = request.getParameter("categoriaLivro1");
        String categoriaLivro2 = request.getParameter("categoriaLivro2");
        List<Categoria> categorias = new ArrayList<>();
        if (categoriaLivro1 != null && !categoriaLivro1.isEmpty()) {
            categorias.add(new Categoria(categoriaLivro1));
        }
        if (categoriaLivro2 != null && !categoriaLivro2.isEmpty() && !categoriaLivro2.equals("(vazio)")) {
            categorias.add(new Categoria(categoriaLivro2));
        }

        // Criando o livro
        Livro livro = new Livro(titulo, sinopse, anoPublicacao, isbn, numPaginas, codBarras, edicao);
        livro.setAutores(autores);
        livro.setEditora(editora1);
        livro.setFornecedor(fornecedor1);
        livro.setGrupoPrecificacao(grupoPrecificacao1);
        livro.setCaracteristicasLivro(caracteristicasLivro1);
        livro.setCategorias(categorias);

        // Salvando o livro através da fachada
        IFachada fachada = new Fachada();
        String mensagemErro = null;
        mensagemErro = fachada.salvar(livro);

        if (mensagemErro != null) {
            request.setAttribute("mensagemErro", mensagemErro);
            request.getRequestDispatcher("/Cadastrar.html").forward(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/index.jsp");
        }


    }
}
