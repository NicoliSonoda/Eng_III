package DAO;

import BancodeDados.OracleDBConnection;
import Dominio.EntidadeDominio;
import Dominio.Livro;
import java.util.List;
import java.sql.*;

public class LivroDAO implements IDAO {

    private EditoraDAO editoraDAO = new EditoraDAO();
    private FornecedorDAO fornecedorDAO = new FornecedorDAO();
    private GrupoPrecificacaoDAO gpDAO = new GrupoPrecificacaoDAO();
    private AutorDAO autorDAO = new AutorDAO();
    private CategoriaDAO categoriaDAO = new CategoriaDAO();

    @Override
    public String salvar(EntidadeDominio entidade) {
        Livro livro = (Livro) entidade;


        String query = "INSERT INTO livros (lvr_titulo, lvr_sinopse, lvr_anoPublicacao, lvr_isbn, lvr_numPaginas, " +
                "lvr_codBarras, lvr_edicao, lvr_valorAquisicao, lvr_valorVenda, lvr_margemLucro, lvr_altura, lvr_peso, lvr_largura, lvr_profundidade, " +
                "lvr_edi_id, lvr_frn_id, lvr_gpc_id) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";


        try (Connection connection = OracleDBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            preparedStatement.setString(1, livro.getTitulo());
            preparedStatement.setString(2, livro.getSinopse());
            preparedStatement.setInt(3, livro.getAnoPublicacao());
            preparedStatement.setString(4, livro.getISBN());
            preparedStatement.setInt(5, livro.getNumPaginas());
            preparedStatement.setString(6, livro.getCodBarras());
            preparedStatement.setString(7, livro.getEdicao());
       //     preparedStatement.setFloat(8, livro.getValorAquisicao());
        //    preparedStatement.setFloat(9, livro.getValorVenda());
        //    preparedStatement.setFloat(10, livro.getMargemLucro());
            preparedStatement.setFloat(11, livro.getCaracteristicasLivro().getAltura());
            preparedStatement.setFloat(12, livro.getCaracteristicasLivro().getPeso());
            preparedStatement.setFloat(13, livro.getCaracteristicasLivro().getLargura());
            preparedStatement.setFloat(14, livro.getCaracteristicasLivro().getProfundidade());
            preparedStatement.setInt(15, editoraDAO.consultarUm(livro.getEditora()));
            preparedStatement.setInt(16, fornecedorDAO.consultarUm(livro.getFornecedor()));
            preparedStatement.setInt(17, gpDAO.consultarUm(livro.getGrupoPrecificacao()));
            preparedStatement.executeUpdate();
            ResultSet resultSet = preparedStatement.getGeneratedKeys();
            if (resultSet.next()) {
                livro.setId(resultSet.getInt(1)); // Define o ID gerado para o livro
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return query;
    }

    private void salvarAutores(Livro livro) {
        String query = "INSERT INTO livros_autores (id_livro, id_autor) VALUES (?, ?)";
        try (Connection connection = OracleDBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            for (EntidadeDominio autor : livro.getAutores()) {
                preparedStatement.setInt(1, livro.getId());
                preparedStatement.setInt(2, autorDAO.consultarUm(autor)); // Obtém o ID do autor
                preparedStatement.addBatch();
            }
            preparedStatement.executeBatch();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar autores do livro: " + e.getMessage());
        }
    }

    private void salvarCategorias(Livro livro) {
        String query = "INSERT INTO livros_categorias (id_livro, id_categoria) VALUES (?, ?)";
        try (Connection connection = OracleDBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            for (EntidadeDominio categoria : livro.getCategorias()) {
                preparedStatement.setInt(1, livro.getId());
                preparedStatement.setInt(2, categoriaDAO.consultarUm(categoria)); // Obtém o ID da categoria
                preparedStatement.addBatch();
            }
            preparedStatement.executeBatch();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar categorias do livro: " + e.getMessage());
        }
    }

    @Override
    public String alterar(EntidadeDominio entidade) {
        // Implemente a lógica para alterar um livro no banco de dados
        return null;
    }

    @Override
    public List<EntidadeDominio> consultar(EntidadeDominio entidade) {
        // Implemente a lógica para consultar livros no banco de dados
        return null;
    }

    @Override
    public String excluir(EntidadeDominio entidade) {
        // Implemente a lógica para excluir um livro do banco de dados
        return null;
    }

    @Override
    public Integer consultarUm(EntidadeDominio entidade) {
        // Implemente a lógica para consultar um único livro no banco de dados
        return null;
    }
}
