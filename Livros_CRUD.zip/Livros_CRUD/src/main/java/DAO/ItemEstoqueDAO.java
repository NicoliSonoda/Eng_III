package DAO;

import Dominio.EntidadeDominio;

import java.util.List;

public class ItemEstoqueDAO {

    public String salvar(EntidadeDominio entidade) {return null;}


    public String alterar(EntidadeDominio entidade) {
        return null;
    }


    public List<EntidadeDominio> consultar(EntidadeDominio entidade) {
        return null;
    }


    public String excluir(EntidadeDominio entidade) {
        return null;
    }
}
