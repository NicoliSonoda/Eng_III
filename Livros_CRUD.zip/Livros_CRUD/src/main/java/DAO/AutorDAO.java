package DAO;

import BancodeDados.OracleDBConnection;
import Dominio.Autor;
import Dominio.EntidadeDominio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AutorDAO implements IDAO{

    @Override
    public Integer consultarUm(EntidadeDominio entidade) {

        Autor autor = (Autor) entidade;

        Integer aut_id = null;
        String sql = "SELECT id FROM autores WHERE nome = ?";

        try (Connection connection = OracleDBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, autor.getPseudonimo());

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                aut_id = resultSet.getInt("id");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return aut_id;
    }

    @Override
    public String salvar(EntidadeDominio entidade) {
        return null;
    }

    @Override
    public String alterar(EntidadeDominio entidade) {
        return null;
    }

    @Override
    public List<EntidadeDominio> consultar(EntidadeDominio entidade) {
        return null;
    }

    @Override
    public String excluir(EntidadeDominio entidade) {
        return null;
    }
}
