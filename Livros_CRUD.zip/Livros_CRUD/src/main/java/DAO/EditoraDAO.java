package DAO;

import Dominio.Editora;
import Dominio.EntidadeDominio;

import java.util.List;

public class EditoraDAO {

    public String salvar(EntidadeDominio entidade) {return null;}


    public String alterar(EntidadeDominio entidade) {
        return null;
    }


    public List<EntidadeDominio> consultar(EntidadeDominio entidade) {
        return null;
    }


    public String excluir(EntidadeDominio entidade) {
        return null;
    }

    public int consultarUm(Editora editora) {return 0;
    }
}
