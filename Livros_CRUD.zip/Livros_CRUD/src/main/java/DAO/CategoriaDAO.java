package DAO;

import BancodeDados.OracleDBConnection;
import Dominio.Categoria;
import Dominio.EntidadeDominio;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO implements IDAO {

    @Override
    public Integer consultarUm(EntidadeDominio entidade) {
        Categoria categoria = (Categoria) entidade;
        Integer cat_id = null;

        List<EntidadeDominio> categorias = new ArrayList<>();
        String sql = "SELECT * FROM categorias";

        try (Connection connection = OracleDBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {

                categoria.setId(resultSet.getInt("cat_id"));
                categoria.setCategoria(resultSet.getString("cat_categoria"));
                categorias.add(categoria);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return cat_id;
    }


    @Override
    public String salvar(EntidadeDominio entidade) {
        return null;
    }

    @Override
    public String alterar(EntidadeDominio entidade) {
        return null;
    }

    @Override
    public List<EntidadeDominio> consultar(EntidadeDominio entidade) {
        return null;
    }

    @Override
    public String excluir(EntidadeDominio entidade) {
        return null;
    }
}
