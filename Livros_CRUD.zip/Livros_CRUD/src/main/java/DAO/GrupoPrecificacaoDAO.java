package DAO;

import Dominio.EntidadeDominio;
import Dominio.GrupoPrecificacao;

import java.util.List;

public class GrupoPrecificacaoDAO {

    public String salvar(EntidadeDominio entidade) {return null;}


    public String alterar(EntidadeDominio entidade) {
        return null;
    }


    public List<EntidadeDominio> consultar(EntidadeDominio entidade) {
        return null;
    }


    public String excluir(EntidadeDominio entidade) {
        return null;
    }

    public int consultarUm(GrupoPrecificacao grupoPrecificacao) {
        return 0;
    }
}
