package Strategy;

import Dominio.EntidadeDominio;
import Dominio.Livro;

//public class AssociarMotivoInat implements IStrategy {

  //  @Override
 //   public String processsar(EntidadeDominio entidade) {
 //       if (entidade instanceof Livro) {
 //           Livro livro = (Livro) entidade;
//
 //           if (livro.isInativo()) {
//
 //               if (livro.getJustificativaInativacao() == null || livro.getJustificativaInativacao().isEmpty()) {
 //                   return "Todo livro inativado manualmente deve ter uma justificativa.";
//                }
//
//                if (livro.getCategoriaInativacao() == null) {
 //                   return "Todo livro inativado manualmente deve ter uma categoria de inativação.";
//}
//            }
//        }
//        return null;
 //   }
//}
