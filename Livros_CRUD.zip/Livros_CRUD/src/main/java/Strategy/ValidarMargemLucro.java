package Strategy;

import Dominio.EntidadeDominio;

//Validar margem de lucro - Um livro somente pode ter seu valor alterado se estiver dentro da
// margem de lucro definida pelo critério de grupo de precificação.
public class ValidarMargemLucro implements IStrategy {
    @Override
    public String processsar(EntidadeDominio entidade) {

// if (novoValor for = da margem de lucro do grupo de especificação
//             "Valor alterado com sucesso!"
// }else{
//           "O novo valor não atende aos critérios do grupo de precificaçõa e a margem de lucro"


        return null;
    }

    @Override
    public String processar(EntidadeDominio entidade) {
        return null;
    }
}
