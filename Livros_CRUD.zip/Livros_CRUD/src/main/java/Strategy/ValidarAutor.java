package Strategy;

import Dominio.Autor;
import Dominio.EntidadeDominio;
import Dominio.Livro;

public class ValidarAutor implements IStrategy {
    @Override
    public String processsar(EntidadeDominio entidade) {

        Livro livro = (Livro) entidade;
        StringBuilder sb = new StringBuilder();

        Autor autor = livro.getAutor();

        if(autor == null) {
            sb.append("Autor é um campo obrigatório");
        }
        if(autor.getPseudonimo() == null){
            sb.append("Pseudônimo é um campo obrigatório");
        }

        String msg = sb.toString();

        if(msg.isEmpty()) {
            return null;

        }else {
            return sb.toString();
        }
    }

    @Override
    public String processar(EntidadeDominio entidade) {
        return null;
    }
}
