package BancodeDados;

import DAO.AutorDAO;
import Dominio.Autor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//public class Conexao {
 //   public static void main(String[] args) {
  //      AutorDAO autorDAO = new AutorDAO();
  //      String a = "zezinho";
  //      System.out.println(autorDAO.adicionarAutor());;
  //  }
//}

