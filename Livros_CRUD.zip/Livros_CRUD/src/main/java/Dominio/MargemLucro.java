package Dominio;

public class MargemLucro {
    private float margem;

    public float getMargem() {
        return margem;
    }

    public void setMargem(float margem) {
        this.margem = margem;
    }
}
