package Dominio;

public class Usuario {
}
