package Dominio;

public abstract class Pessoa extends EntidadeDominio{
    private String nome;

    public Pessoa(String nome) {
        this.nome = nome;
    }
}
